# StenBot Source Code

Hello! You have reached the official source code for StenBot, the best public Discord Bot in the entire world. 
There isn't much here yet but there might be soon. 

## Documentation

There's currently no documentation files made for StenBot as of yet but when there is, this will be updated with them!


## Features

A whole list of features can be found over at [StenBot's website](https://sb.benwhybrow.xyz)! 

## Inviting The Bot

To invite the bot, head over to the bot's page [here](https://sbinvite.benwhybrow.xyz) and choose your server from the dropdown. Be sure to allow the bot **administrator permissions** otherwise it cannot work functionally. 

## Support Discord

StenBot's support Discord can be found over at [https://discord.benwhybrow.xyz/](https://discord.benwhybrow.xyz/) where you can get all the assistance you need with StenBot!
