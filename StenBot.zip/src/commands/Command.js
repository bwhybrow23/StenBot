export class Command {
    
}
