class DelChannel extends Command {
    
}
