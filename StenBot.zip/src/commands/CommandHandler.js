/**
 * 
 */
class CommandHandler {
    constructor(prefix) {
        this.prefix = prefix;
    }
}

export { CommandHandler };

