import EventHandler from './EventHandler';

export { EventHandler };

