/**
 * 
 */
export default class Event {
    constructor(name) {
        this.name = name;
    }
};
